export default ['packages/*']
