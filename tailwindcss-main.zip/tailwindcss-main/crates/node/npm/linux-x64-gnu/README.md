# `@tailwindcss/oxide-linux-x64-gnu`

This is the **x86_64-unknown-linux-gnu** binary for `@tailwindcss/oxide`
