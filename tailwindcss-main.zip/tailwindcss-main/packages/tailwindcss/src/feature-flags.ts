export const enableInvertedColors = process.env.FEATURES_ENV !== 'stable'
export const enableUserValid = process.env.FEATURES_ENV !== 'stable'
export const enableWrapAnywhere = process.env.FEATURES_ENV !== 'stable'
